# Assignment: Ninja to Cat
## Author: Jose Lechuga

### Project Specifications
Create a jQuery puzzle using two images sliced into five parts. Using jQuery, make it so that when each image slice is clicked, it will change to a different picture. You may use your own pictures and crop them or you can just download the images provided 

So go ahead and try it just click on each square and see what lies underneath.
